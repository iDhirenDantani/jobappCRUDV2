import { getConnection } from "../config/db.js";

const connection = await getConnection();

export async function fetchConfig() {
  const [inputs] = await connection.query("SELECT * from input_master");
  const [options] = await connection.query("SELECT * FROM option_master");

  let data = {
    inputs,
    options,
  };

  return data;
}

export async function createApplicant(formBody) {
  console.log(formBody);
  let step = "applicant_details";

  try {
    await connection.beginTransaction();

    console.log("[CRUD] Step:", step);
    const [result] = await connection.execute(
      `INSERT INTO applicant_details (first_name, last_name, designation, email, phone_number, gender, relationship_status, date_of_birth) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formBody.first_name,
        formBody.last_name,
        formBody.designation,
        formBody.email,
        formBody.phone_number,
        formBody.gender,
        formBody.relationship_status,
        formBody.dob,
      ],
    );
    const applicantId = result.insertId;

    step = "applicant_addresses";
    console.log("[CRUD] Step:", step);
    await connection.execute(
      `INSERT INTO applicant_addresses (applicant_id, address_1, address_2, city, state, zip_code) VALUES (?, ?, ?, ?, ?, ?)`,
      [
        applicantId,
        formBody.address_1,
        formBody.address_2 || null,
        formBody.city,
        formBody.state,
        formBody.zip_code,
      ],
    );

    step = "education_records";
    console.log("[CRUD] Step:", step);
    if (formBody.degree && Array.isArray(formBody.degree)) {
      for (let i = 0; i < formBody.degree.length; i++) {
        let degree = formBody.degree[i];
        let passingYear = formBody.year_of_passing[i];
        let board_university = formBody.board_university[i];
        let result = formBody.result[i];

        if (degree && passingYear && board_university && result) {
          await connection.execute(
            `INSERT INTO education_records (applicant_id, course_name, passing_year, board_university, result_percentage) VALUES (?, ?, ?, ?, ?)`,
            [
              applicantId,
              degree,
              passingYear,
              board_university,
              parseFloat(result),
            ],
          );
        }
      }
    }

    step = "work_experiences";
    console.log("[CRUD] Step:", step);
    if (formBody.company_name && Array.isArray(formBody.company_name)) {
      for (let i = 0; i < formBody.company_name.length; i++) {
        let companyName = formBody.company_name[i];
        let jobTitle = formBody.job_title[i];
        let startDate = formBody.start_date[i];
        let salary = formBody.salary[i];
        let endDate = formBody.end_date[i];
        let leavingReason = formBody.description[i];

        if (
          companyName &&
          jobTitle &&
          startDate &&
          endDate &&
          salary &&
          leavingReason
        ) {
          await connection.execute(
            `INSERT INTO work_experiences (applicant_id, company_name, designation, from_date, to_date, package, leaving_reason) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
              applicantId,
              companyName,
              jobTitle,
              startDate,
              endDate,
              parseFloat(salary),
              leavingReason,
            ],
          );
        }
      }
    }

    step = "languages_known";
    console.log("[CRUD] Step:", step);
    if (formBody.languages_known && Array.isArray(formBody.languages_known)) {
      for (const lang of formBody.languages_known) {
        const langId = lang.toLowerCase();
        const canRead = formBody[`read_${langId}`] === "on";
        const canWrite = formBody[`write_${langId}`] === "on";
        const canSpeak = formBody[`speak_${langId}`] === "on";
        await connection.execute(
          `INSERT INTO languages_known (applicant_id, language_name, can_read, can_write, can_speak) VALUES (?, ?, ?, ?, ?)`,
          [applicantId, lang, canRead, canWrite, canSpeak],
        );
      }
    }

    step = "technologies_known";
    console.log("[CRUD] Step:", step);
    if (formBody.tech_known && Array.isArray(formBody.tech_known)) {
      for (const tech of formBody.tech_known) {
        const techId = tech.toLowerCase().replace(/\./g, "").replace(/ /g, "");
        const level = formBody[`level_${techId}`];
        if (level) {
          await connection.execute(
            `INSERT INTO technologies_known (applicant_id, tech_name, proficiency_level) VALUES (?, ?, ?)`,
            [applicantId, tech, level],
          );
        }
      }
    }

    step = "applicant_preferences";
    console.log("[CRUD] Step:", step);
    const insertIntoApplicantPreferences =
      "INSERT into applicant_preferences(applicant_id,pref_location_1,pref_location_2,pref_location_3,notice_period_days,expected_ctc,current_ctc,department) values(?,?,?,?,?,?,?,?)";
    await connection.query(insertIntoApplicantPreferences, [
      applicantId,
      formBody.lp1,
      formBody.lp2,
      formBody.lp3,
      parseInt(formBody["notice_period_days"]),
      parseFloat(formBody["expected_ctc"]),
      parseFloat(formBody["current_ctc"]),
      formBody.department,
    ]);

    await connection.commit();
  } catch (error) {
    await connection.rollback();
    console.error("[CRUD] Error during step:", step, error);
    res.status(500).send(`Error submitting application at step: ${step}`);
  }
}
