import 'dotenv/config'
import express, { urlencoded } from 'express'
import applicantRoutes from './routes/applicantRoutes.js'

const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.static('public'))
app.use(express.urlencoded({extended:true}));

app.set('view engine','ejs');


app.use('/',applicantRoutes);


app.listen(PORT, () => {
    console.log(`App running on the URI: http://localhost:${PORT}`);
})