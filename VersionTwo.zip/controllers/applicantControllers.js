import { fetchConfig } from "../services/applicantServices.js";

export async function redirectHome(req,res) {
    res.redirect('/form')
}

export async function renderForm(req,res){
    res.render('form');
}

export async function getFormConfig(req,res) {
    const data = await fetchConfig();
    res.json(data);
}

export async function getReqBody(req,res) {
    res.send(req.body);
}