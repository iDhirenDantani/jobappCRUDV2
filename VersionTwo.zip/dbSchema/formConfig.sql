create database form_config;
use form_config;

CREATE TABLE input_master (
    id INT PRIMARY KEY AUTO_INCREMENT,
    html_type VARCHAR(20),
    html_label VARCHAR(50),
    html_id VARCHAR(50),
    html_name VARCHAR(50),
    placeholder VARCHAR(100),
    parent_select_id INT DEFAULT NULL
);

insert into input_master(html_type,html_id,html_label,html_name) values('select','relationship_status','Relationship Status','relationship_status');
insert into input_master(html_type,html_id,html_label,html_name) values('radio','gender','Gender','gender');
insert into input_master(html_type,html_id,html_label,html_name) values('select','state','State','state');
insert into input_master(html_type,html_id,html_label,html_name,parent_select_id) values('select','city','City','city',3);
insert into input_master(html_type,html_id,html_label,html_name) values('select','degree','Degree/Courses','degree[]');
insert into input_master(html_type,html_id,html_label,html_name) values('select','lp','Location Priority  : ','lp');

SELECT 
    *
FROM
    input_master;


CREATE TABLE option_master (
    option_id INT PRIMARY KEY AUTO_INCREMENT,
    input_id INT NOT NULL,
    html_value VARCHAR(50),
    html_label VARCHAR(50),
    FOREIGN KEY (input_id)
        REFERENCES input_master(id)
);

SELECT 
    *
FROM
    option_master;
insert into option_master(input_id,html_value,html_label) values(1,'single','Single'),(1,'married','Married'),(1,'divorced','Divorced'),(1,'widowed','Widowed');
insert into option_master(input_id,html_value,html_label) values(2,'male','Male'),(2,'female','Female');
insert into option_master(input_id,html_value,html_label) values(2,'other','Other');
insert into option_master(input_id,html_value,html_label) values(1,'commited','Commited');
insert into option_master(input_id,html_value,html_label) values(1,'commited','Commited');

insert into option_master(input_id,html_value,html_label) values(5,'SSC','SSC/10th');
insert into option_master(input_id,html_value,html_label) values(5,'HSC','HSC/12th');
insert into option_master(input_id,html_value,html_label) values(5,'Diploma','Diploma/Polytechnic');
insert into option_master(input_id,html_value,html_label) values(5,'Btech','B.Tech');
insert into option_master(input_id,html_value,html_label) values(5,'Mtech','M.Tech');
insert into option_master(input_id,html_value,html_label) values(5,'PhD','PhD');
-- inserting options for state dropdown;
INSERT INTO option_master (input_id, html_value, html_label)
VALUES
(3, 'andhra pradesh', 'Andhra Pradesh'),
(3, 'arunachal pradesh', 'Arunachal Pradesh'),
(3, 'assam', 'Assam'),
(3, 'bihar', 'Bihar'),
(3, 'chhattisgarh', 'Chhattisgarh'),
(3, 'goa', 'Goa'),
(3, 'gujarat', 'Gujarat'),
(3, 'haryana', 'Haryana'),
(3, 'himachal pradesh', 'Himachal Pradesh'),
(3, 'jammu and kashmir', 'Jammu and Kashmir'),
(3, 'jharkhand', 'Jharkhand'),
(3, 'karnataka', 'Karnataka'),
(3, 'kerala', 'Kerala'),
(3, 'madhya pradesh', 'Madhya Pradesh'),
(3, 'maharashtra', 'Maharashtra'),
(3, 'manipur', 'Manipur'),
(3, 'meghalaya', 'Meghalaya'),
(3, 'mizoram', 'Mizoram'),
(3, 'nagaland', 'Nagaland'),
(3, 'odisha', 'Odisha'),
(3, 'punjab', 'Punjab'),
(3, 'rajasthan', 'Rajasthan'),
(3, 'sikkim', 'Sikkim'),
(3, 'tamil nadu', 'Tamil Nadu'),
(3, 'telangana', 'Telangana'),
(3, 'tripura', 'Tripura'),
(3, 'uttar pradesh', 'Uttar Pradesh'),
(3, 'uttarakhand', 'Uttarakhand'),
(3, 'west bengal', 'West Bengal'),
(3, 'andaman and nicobar islands', 'Andaman and Nicobar Islands'),
(3, 'chandigarh', 'Chandigarh'),
(3, 'dadra and nagar haveli', 'Dadra and Nagar Haveli'),
(3, 'daman and diu', 'Daman and Diu'),
(3, 'delhi', 'Delhi'),
(3, 'lakshadweep', 'Lakshadweep'),
(3, 'puducherry', 'Puducherry');



INSERT INTO option_master (input_id, html_value, html_label, parent_option_id)
VALUES 
(4, 'ahmedabad', 'Ahmedabad', 14),
(4, 'surat', 'Surat', 14),
(4, 'vadodara', 'Vadodara', 14),
(4, 'rajkot', 'Rajkot', 14),
(4, 'bhavnagar', 'Bhavnagar', 14),
(4, 'jamnagar', 'Jamnagar', 14),
(4, 'junagadh', 'Junagadh', 14),
(4, 'gandhinagar', 'Gandhinagar', 14),
(4, 'anand', 'Anand', 14),
(4, 'mehsana', 'Mehsana', 14); 

select * from option_master where input_id = 3;

INSERT INTO option_master (input_id, html_value, html_label, parent_option_id)
VALUES 
(4, 'thiruvananthapuram', 'Thiruvananthapuram', 20),
(4, 'kochi', 'Kochi', 20),
(4, 'kozhikode', 'Kozhikode', 20),
(4, 'kollam', 'Kollam', 20),
(4, 'thrissur', 'Thrissur', 20),
(4, 'kannur', 'Kannur', 20),
(4, 'alappuzha', 'Alappuzha', 20),
(4, 'kottayam', 'Kottayam', 20),
(4, 'palakkad', 'Palakkad', 20),
(4, 'malappuram', 'Malappuram', 20);   

 
-- what things do we need...
-- type , label id name from input_master table  ,
-- option ki html_value html_label we need this much from both the tables

SELECT 
    im.html_type,
    im.html_label,
    im.html_id,
    im.html_name,
    om.html_label as 'option_label',
    om.html_value
FROM
    input_master AS im
        LEFT JOIN
    option_master AS om ON im.id = om.input_id;

