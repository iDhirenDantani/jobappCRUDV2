async function fetchFields() {
  const response = await fetch("http://localhost:5050/fetchconfig");
  const data = await response.json();

  console.log("function Ran!");
  console.log(data);

  data.inputs.forEach((field) => {
    if (field.html_type === "select") {
      if (field.html_id === "relationship_status") {
        const options = data.options.filter((opt) => opt.input_id === field.id);
        
        const html = createSelect(field.html_name, field.html_id, options);
        const relDiv = document.getElementById("relDiv");
        relDiv.insertAdjacentHTML("beforeend", html);
      }
      if (field.html_id === "state") {
        const stateOptions = data.options.filter(
          (opt) => opt.input_id === field.id,
        );
        const stateSelectHtml = createSelect(
          field.html_name,
          field.html_id,
          stateOptions,
        );

        const stateDiv = document.getElementById("stateDiv");
        stateDiv.insertAdjacentHTML("beforeend", stateSelectHtml);

        // get all the dropdown for state and city..
        const stateDropdown = document.getElementById("state");
        const cityDiv = document.getElementById("cityDiv");

        stateDropdown.addEventListener("change", function () {
          const dataOidAttr = this.options[this.selectedIndex].getAttribute("data-oid");
          const parentId = parseInt(dataOidAttr);

          const cityDropDownHtml = "";

          cityDiv.innerHTML = '<label for="city">City:</label>';
          if (parentId) {
            const cityOptions = data.options.filter(
              (opt) => opt.parent_option_id === parentId,
            );
            
            if(cityOptions) {
                const cityDropDownHtml = createSelect("city", "city", cityOptions);
                cityDiv.style.visibility = "";
                cityDiv.insertAdjacentHTML("beforeend", cityDropDownHtml);
            } else {
                cityDiv.style.visibility = "hidden";
            }
            
          }
        });
      }

      if(field.html_name === 'lp'){
        const locationPreferenceDiv = document.getElementById('lpDiv');

        const lpOptions = data.options.filter(opt => opt.input_id === field.id);
        console.log('This are the priority Location Options :');
        for(let i = 1; i <= lpOptions.length; i++) {
          const newDiv = document.createElement('div');
          newDiv.classList.add('input-group');
          let selectHtml = `<label for='lp${i}'>${field.html_label}${i}</label>`
          selectHtml += createSelect(`${field.html_name}${i}`,`${field.html_name}${i}`,lpOptions);
          newDiv.insertAdjacentHTML('beforeend',selectHtml);
          locationPreferenceDiv.appendChild(newDiv);
        }
      }
       
      if(field.html_id === 'department') {
        const departmentDiv = document.getElementById('deptDiv');
        const deptOptions = data.options.filter(opt => opt.input_id === field.id);
        const deptDropdownHtml = createSelect(field.html_name,field.html_id,deptOptions);
        departmentDiv.insertAdjacentHTML('beforeend',deptDropdownHtml);
      }
      if (field.html_name === "degree[]") {
        const degreeDropdown = document.querySelectorAll(".degreeDropdown");
        const degreeOptions = data.options.filter(
          (opt) => opt.input_id === field.id,
        );

        const degreehtml = createSelect(
          field.html_name,
          field.html_id,
          degreeOptions,
        );

        if (degreeDropdown) {
          degreeDropdown.forEach((td) => {
            td.innerHTML = degreehtml;
          });
        }

        const educationTable = document.getElementById("education-body");
        const addEduBtn = document.getElementById("btn-add-edu");
        const remEduBtn = document.getElementById("btn-remove-edu");

        addEduBtn.addEventListener("click", function () {
          const rowCount = educationTable.children.length + 1;
          const newRow = document.createElement("tr");
          const degreeTd = document.createElement("td");
          const countTd = document.createElement("td");
          degreeTd.classList.add("degreeDropdown");
          degreeTd.innerHTML = degreehtml;
          countTd.innerHTML = rowCount;
          newRow.appendChild(countTd);
          newRow.appendChild(degreeTd);
          const newRowHtml = `
                    <tr>
                        <td><input type="text" name="year_of_passing[]"></td>
                        <td><input type="text" name="board_university[]"></td>
                        <td><input type="text" name="result[]"></td>
                    <td><button  type="button" onclick="removeCurrentRecord(this)">Remove</button></td>
                    </tr>
        `;
          newRow.insertAdjacentHTML("beforeend", newRowHtml);
          educationTable.appendChild(newRow);
        });

        remEduBtn.addEventListener("click", function () {
          let isConfirmed = confirm(
            "Are you sure you want to delete last Record??",
          );

          if (isConfirmed && educationTable.childElementCount > 1) {
            const lastEle = educationTable.lastElementChild;
            educationTable.removeChild(lastEle);
          } else if (educationTable.childElementCount <= 1) {
            alert("You should atleast have one education Record!!");
          } else {
            return;
          }
        });
      }
    }
    if (field.html_type === "radio") {
      if ((field.html_name = "gender")) {
        const options = data.options.filter((opt) => opt.input_id === field.id);
        const radioHtml = createRadio(field.html_name, options);
        console.log(radioHtml);
        const genderDiv = document.getElementById("genderDiv");
        genderDiv.insertAdjacentHTML("beforeend", radioHtml);
      }
    }

    if(field.html_type === 'checkbox'){
     if(field.html_id === 'languages'){
        const langOptions = data.options.filter(opt => opt.input_id === field.id);
        console.log(langOptions);
        console.log('This are the languages options in your db')
        renderLanguages(`${field.html_id}`,`${field.html_name}`,langOptions);
      }

      if(field.html_id === 'technologies'){
          const techOptions = data.options.filter(opt => opt.input_id === field.id);
          renderTechnologies(`${field.html_id}`,`${field.html_name}`,techOptions);
      }
    }
  });
}

function createSelect(name, id, options) {
  let html = `<select name='${name}' id='${id}'> <option value="" selected disabled>Select ${name}</option>`;

  options.forEach((opt) => {
    html += `<option value='${opt.html_value}' data-oid='${opt.option_id}'>${opt.html_label}</option>`;
  });

  html += `</select> <span id="error-${id}" class="error-text"></span> `;

  return html;
}

function createRadio(name, options) {
  let html = ``;
  options.forEach((opt) => {
    html += `
                <input type='radio' name='${name}' value='${opt.html_value}' id='${opt.html_value}'>
                <label for='${opt.html_value}'>${opt.html_label}</label> 
                `;
  });

  return html;
}
function removeCurrentRecord(ele) {
  const educationTable = document.getElementById("education-body");
  if (educationTable.childElementCount <= 1) {
    alert("You should atleast have one record in education table!!");
    return;
  } else {
    const isConfirmed = confirm(
      "Your record data will be lost!! Are you sure you want to remove this record??",
    );
    if (isConfirmed) {
      ele.closest("tr").remove();
    } else {
      return;
    }
  }
}

const addWorkBtn = document.getElementById("btn-add-work");
const remWorkBtn = document.getElementById("btn-remove-work");

function addWorkRecord() {
  const workExpTable = document.getElementById("workExp-body");
  const rowCount = workExpTable.childElementCount + 1;

  const newRowHTML = `
         <tr>
                        <td>${rowCount}</td>
                        <td><input type="text" name="company_name[]"></td>
                        <td><input type="text" name="job_title[]"></td>
                        <td><input type="date" name="start_date[]"></td>
                        <td><input type="date" name="end_date[]"></td>
                        <td><input type="number" name="salary[]"></td>
                        <td><input type="text" name="description[]"></td>
                        <td><button type="button" onclick="removeCurrentRecord(this)">Remove</button></td>
        </tr>
        `;
  workExpTable.insertAdjacentHTML("beforeend", newRowHTML);
}

addWorkBtn.addEventListener("click", addWorkRecord);
remWorkBtn.addEventListener("click", function () {
  const workExpTable = document.getElementById("workExp-body");
  let isConfirmed = confirm("Are you sure you want to delete last Record??");

  if (isConfirmed && workExpTable.childElementCount > 0) {
    const lastEle = workExpTable.lastElementChild;
    workExpTable.removeChild(lastEle);
  } else {
    return;
  }
});

function renderLanguages(id,name,options){
  for (let i = 0; i < options.length; i++) {
            const langBody = document.getElementById('lang-body')
            let langName = options[i].html_label;
            let langId = langName.toLowerCase();
            let newLangRow = document.createElement('tr');
            
            newLangRow.innerHTML = `
                <td>
                    <input type="checkbox" id="lang_${langId}" name="${name}" value="${langName}">
                    <label for="lang_${langId}">${langName}</label>
                </td>
                <td>
                    <input type="checkbox" id="read_${langId}" name="read_${langId}" disabled>
                    <label for="read_${langId}">Read</label>
                </td>
                <td>
                    <input type="checkbox" id="write_${langId}" name="write_${langId}" disabled>
                    <label for="write_${langId}">Write</label>
                </td>
                <td>
                    <input type="checkbox" id="speak_${langId}" name="speak_${langId}" disabled>
                    <label for="speak_${langId}">Speak</label>
                </td>
            `;
            langBody.appendChild(newLangRow); 
             let mainLangCheckbox = document.getElementById(`lang_${langId}`);
            mainLangCheckbox.addEventListener('change', function() {
                let readBox = document.getElementById(`read_${langId}`);
                let writeBox = document.getElementById(`write_${langId}`);
                let speakBox = document.getElementById(`speak_${langId}`);

                if (this.checked) {
                    readBox.disabled = false;
                    writeBox.disabled = false;
                    speakBox.disabled = false;
                } else {
                    readBox.disabled = true;
                    writeBox.disabled = true;
                    speakBox.disabled = true;
                    readBox.checked = false;
                    writeBox.checked = false;
                    speakBox.checked = false;
                    newLangRow.style.backgroundColor = ""; 
                }
            });           
}
}


function renderTechnologies(id,name,options){
      const techBody = document.getElementById('tech-body');
      for (let i = 0; i < options.length; i++) {
            let techName = options[i].html_label;
            let techId = techName.toLowerCase().replace(/\./g, '').replace(/ /g, '');
            let newTechRow = document.createElement('tr');

            newTechRow.innerHTML = `
                <td>
                    <input type="checkbox" id="tech_${techId}" name="${name}" value="${techName}">
                    <label for="tech_${techId}">${techName}</label>
                </td>
                <td>
                    <input type="radio" id="beginner_${techId}" name="level_${techId}" value="beginner" disabled>
                    <label for="beginner_${techId}">Beginner</label>
                </td>
                <td>
                    <input type="radio" id="intermediate_${techId}" name="level_${techId}" value="intermediate" disabled>
                    <label for="intermediate_${techId}">Intermediate</label>
                </td>
                <td>
                    <input type="radio" id="advanced_${techId}" name="level_${techId}" value="advanced" disabled>
                    <label for="advanced_${techId}">Advanced</label>
                </td>
            `;
            techBody.appendChild(newTechRow);

            let mainTechCheckbox = document.getElementById(`tech_${techId}`);
            mainTechCheckbox.addEventListener('change', function() {
                let beginnerRadio = document.getElementById(`beginner_${techId}`);
                let intermediateRadio = document.getElementById(`intermediate_${techId}`);
                let advancedRadio = document.getElementById(`advanced_${techId}`);

                if (this.checked) {
                    beginnerRadio.disabled = false;
                    intermediateRadio.disabled = false;
                    advancedRadio.disabled = false;
                } else {
                    beginnerRadio.disabled = true;
                    intermediateRadio.disabled = true;
                    advancedRadio.disabled = true;
                    beginnerRadio.checked = false;
                    intermediateRadio.checked = false;
                    advancedRadio.checked = false;
                    newTechRow.style.backgroundColor = "";
                }
            });
}
}