import express from 'express'
import { renderForm,redirectHome , getFormConfig , getReqBody } from '../controllers/applicantControllers.js';


const router = express.Router();


router.get('/',redirectHome);
router.get('/form',renderForm);
router.get('/fetchconfig',getFormConfig);
router.post('/form/add',getReqBody);
export default router;